function toggleMenu() {
    const nav = document.getElementById('navbar');
    nav.classList.toggle('active');
}
